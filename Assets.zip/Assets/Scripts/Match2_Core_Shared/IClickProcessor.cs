public interface IClickProcessor
{
    void ProcessClick(int x, int y);
    
}