public interface IInputHandler
{
    void HandleInput();
}